// package mrfast.skyblockfeatures.utils;

// public class Friend
// {
//     public Friend(String p_Name)
//     {
//         Name = p_Name;
//     }
    
//     private String Name;
    
//     public String GetName()
//     {
//         return Name;
//     }

// }
